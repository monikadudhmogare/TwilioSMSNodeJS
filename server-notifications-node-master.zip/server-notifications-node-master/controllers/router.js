// Map routes to controller functions
module.exports = function(router) {
  router.get('/notification', function(req, resp) {
    throw new Error('Derp. An error occurred.');
  });
};
